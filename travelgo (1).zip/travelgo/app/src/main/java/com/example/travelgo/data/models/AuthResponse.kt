package com.example.travelgo.data.models

data class AuthResponse(
    val authToken: String,
    val user: User
)
