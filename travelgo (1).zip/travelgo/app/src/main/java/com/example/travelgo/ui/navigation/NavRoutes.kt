package com.example.travelgo.ui.navigation

object NavRoutes {
    const val LOGIN = "login"
    const val HOME = "home"
    const val DETALLE = "detalle/{paqueteId}"
    const val PERFIL = "perfil"
}
